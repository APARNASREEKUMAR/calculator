
<?php

class Calculator 
{
	

	public function summation($input,$delimiter){
			$sum=0;
			$neg_flag=0;
			$neg=array();
			$neg_str="";
			if(isset($input)){
			$input=str_replace('\n',$delimiter, $input);		
			$input=rtrim($input,$delimiter);
			$param =explode($delimiter, $input);
			foreach ($param as $key ) {
			if($key>=0 && $key <=1000){
			$sum+=$key;
			}elseif($key<0){
				$neg_flag=1;
				array_push($neg, $key);
			}
			}

			}

			if($neg_flag==0){
			return $sum;
			}else{
			foreach ($neg as $neg_value) {
			$neg_str.=$neg_value;
			$neg_str.=",";
			}
			$neg_str=rtrim($neg_str,',');
			$neg_str="(".$neg_str.")";
			return "Error: Negative numbers ".$neg_str." not allowed";
			}
			
	}
}


if($argv[1] =='sum'|| $argv[1] =='add'){

	$output=0;
	$calc_obj=new Calculator;
	if(isset($argv[2])){
		$input=$argv[2];
	

	$delimiter_check=explode('\\', $input);
	// print_r($delimiter_check);
	if(isset($delimiter_check[4])){
		$delimiter=$delimiter_check[2];
		$input=$delimiter_check[4];

	}else{
		
		$input=preg_replace('/[^a-zA-Z0-9_ -]/s',',',$argv[2]);
		$delimiter=",";
		$input=$input;
	}
}

	$output=$calc_obj->summation($input,$delimiter);
}else{

	echo "============================================ \n ";
	echo "Program Customised to handle only Summation \n Exiting Application\n " ;
	echo "============================================ \n ";
	return;

}
echo $output;
?>