<?php

class Calculator 
{
	

	public function summation($input){
			$sum=0;
			if(isset($input)){
			$input=rtrim($input,',');
			$param =explode(',', $input);
			foreach ($param as $key ) {
			$sum+=$key;
			}

			}
	return $sum;		
	}
}


if($argv[1] !=='sum'){
	echo "============================================ \n ";
	echo "Program Customised to handle only Summation \n Exiting Application\n " ;
	echo "============================================ \n ";
	return;
}else{
$output=0;
if(isset($argv[2])){
	$calc_obj=new Calculator;
	$input=$argv[2];
	$output=$calc_obj->summation($input);
	}
}
echo "SUM=".$output;
?>