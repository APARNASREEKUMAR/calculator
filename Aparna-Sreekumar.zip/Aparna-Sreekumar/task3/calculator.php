<?php

class Calculator 
{
	

	public function summation($input){
			$sum=0;
			if(isset($input)){
			$input=str_replace('\n',',', $input);		
			$input=rtrim($input,',');
			$param =explode(',', $input);
			foreach ($param as $key ) {
			$sum+=$key;
			}

			}
	return $sum;		
	}
}


if($argv[1] =='sum'|| $argv[1] =='add'){

	$output=0;
	if(isset($argv[2])){
	$calc_obj=new Calculator;
	$input=$argv[2];
	$output=$calc_obj->summation($input);
	}

}else{

	echo "============================================ \n ";
	echo "Program Customised to handle only Summation \n Exiting Application\n " ;
	echo "============================================ \n ";
	return;

}
echo "SUM=".$output;
?>