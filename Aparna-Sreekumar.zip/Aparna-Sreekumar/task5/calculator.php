
<?php

class Calculator 
{
	

	public function summation($input,$delimiter){
			$sum=0;
			if(isset($input)){
			$input=str_replace('\n',$delimiter, $input);		
			$input=rtrim($input,$delimiter);
			$param =explode($delimiter, $input);
			foreach ($param as $key ) {
			if($key>=0){
			$sum+=$key;
			}else{
				echo "Error: Negative numbers not allowed.";
				exit;
			}
			}

			}
	return $sum;		
	}
}


if($argv[1] =='sum'|| $argv[1] =='add'){

	$output=0;
	$calc_obj=new Calculator;
	if(isset($argv[2])){
		$input=$argv[2];
	

	$delimiter_check=explode('\\', $input);
	// print_r($delimiter_check);
	if(isset($delimiter_check[4])){
		$delimiter=$delimiter_check[2];
		$input=$delimiter_check[4];

	}else{
		
		$input=preg_replace('/[^a-zA-Z0-9_ -]/s',',',$argv[2]);
		$delimiter=",";
		$input=$input;
	}
}

	$output=$calc_obj->summation($input,$delimiter);
}else{

	echo "============================================ \n ";
	echo "Program Customised to handle only Summation \n Exiting Application\n " ;
	echo "============================================ \n ";
	return;

}
echo "SUM=".$output;
?>